import java.util.Scanner;

public class subnet_5_7340 {

    // Convert IP string to binary
    public static String toBinaryIP(String ip) {
        String[] parts = ip.split("\\.");
        StringBuilder binaryIP = new StringBuilder();
        for (String part : parts) {
            int val = Integer.parseInt(part);
            String bin = String.format("%8s", Integer.toBinaryString(val)).replace(' ', '0');
            binaryIP.append(bin).append(".");
        }
        return binaryIP.substring(0, binaryIP.length() - 1);
    }

    // Convert binary string to dotted decimal format
    public static String binaryToDecimalIP(String binary) {
        String[] parts = binary.split("\\.");
        StringBuilder ip = new StringBuilder();
        for (String part : parts) {
            ip.append(Integer.parseInt(part, 2)).append(".");
        }
        return ip.substring(0, ip.length() - 1);
    }

    // Generate subnet mask from prefix length
    public static String getSubnetMask(int prefixLength) {
        StringBuilder mask = new StringBuilder();
        for (int i = 0; i < 32; i++) {
            mask.append(i < prefixLength ? "1" : "0");
            if ((i + 1) % 8 == 0 && i != 31) mask.append(".");
        }
        return mask.toString();
    }

    // Main method
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input IP address
        System.out.print("Enter IP address (e.g. 192.168.1.0): ");
        String ip = scanner.nextLine();

        // Binary form of IP
        String binaryIP = toBinaryIP(ip);
        System.out.println("Binary form of IP: " + binaryIP);

        // Input network mask (CIDR)
        System.out.print("Enter Network Mask (CIDR, e.g. 24): ");
        int cidr = scanner.nextInt();

        String originalMask = getSubnetMask(cidr);
        System.out.println("Network Mask: " + binaryToDecimalIP(originalMask));

        // Input number of subnets
        System.out.print("Enter the number of subnets required: ");
        int numSubnets = scanner.nextInt();

        // Calculate bits to borrow
        int bitsBorrowed = (int) Math.ceil(Math.log(numSubnets) / Math.log(2));
        int newCidr = cidr + bitsBorrowed;
        int totalSubnets = (int) Math.pow(2, bitsBorrowed);
        int hostsPerSubnet = (int) Math.pow(2, 32 - newCidr) - 2;

        System.out.println("Bits borrowed: " + bitsBorrowed);
        System.out.println("New Subnet Mask (CIDR): /" + newCidr);
        String newMask = getSubnetMask(newCidr);
        System.out.println("New Subnet Mask: " + binaryToDecimalIP(newMask));
        System.out.println("Number of subnets created: " + totalSubnets);
        System.out.println("Hosts per subnet: " + hostsPerSubnet);

        // Print all subnet addresses
        System.out.println("\nSubnet Addresses:");
        String[] ipParts = ip.split("\\.");
        int baseIP = (Integer.parseInt(ipParts[0]) << 24) |
                     (Integer.parseInt(ipParts[1]) << 16) |
                     (Integer.parseInt(ipParts[2]) << 8) |
                     Integer.parseInt(ipParts[3]);

        int increment = (int) Math.pow(2, 32 - newCidr);

        for (int i = 0; i < totalSubnets; i++) {
            int subnetIP = baseIP + (i * increment);
            String subnetAddress = ((subnetIP >> 24) & 0xFF) + "." +
                                   ((subnetIP >> 16) & 0xFF) + "." +
                                   ((subnetIP >> 8) & 0xFF) + "." +
                                   (subnetIP & 0xFF);
            System.out.println("Subnet " + (i + 1) + ": " + subnetAddress + "/" + newCidr);
        }

        scanner.close();
    }
}
