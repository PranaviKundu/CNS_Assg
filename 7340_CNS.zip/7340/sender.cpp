// sender.cpp
#include <iostream>
#include <unistd.h>
#include <arpa/inet.h>
#include <string.h>
#include <thread>
#include <chrono>
#include <vector>
#include <limits>

using namespace std;

#define WINDOW_SIZE 4

string MODE = "GBN";
int base = 0, nextSeqNum = 0;
vector<string> packets;
bool acked[100] = {false};
int total_packets = 0;

void send_packet(int sockfd, sockaddr_in &receiverAddr, int seqNum) {
    if (seqNum >= (int)packets.size()) return;

    char buffer[1024];
    sprintf(buffer, "Packet %d:%s", seqNum, packets[seqNum].c_str());
    sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr*)&receiverAddr, sizeof(receiverAddr));
    cout << "[SENDER] Sent Packet " << seqNum << ": " << packets[seqNum] << endl;
}

void sender_thread(int sockfd, sockaddr_in &receiverAddr) {
    while (base < total_packets) {
        while (nextSeqNum < base + WINDOW_SIZE && nextSeqNum < total_packets) {
            if (MODE == "SR" && acked[nextSeqNum]) {
                nextSeqNum++;
                continue;
            }
            send_packet(sockfd, receiverAddr, nextSeqNum);
            nextSeqNum++;
        }
        this_thread::sleep_for(chrono::milliseconds(500));
    }
}

void receiver_ack_thread(int sockfd, int total_packets) {
    char buffer[1024];
    sockaddr_in fromAddr;
    socklen_t addrLen = sizeof(fromAddr);

    while (base < total_packets) {
        int len = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr*)&fromAddr, &addrLen);
        if (len > 0) {
            buffer[len] = '\0';
            int ackNum;
            if (sscanf(buffer, "ACK %d", &ackNum) == 1) {
                cout << "[SENDER] Received ACK " << ackNum << endl;

                if (MODE == "GBN") {
                    if (ackNum >= base) {
                        base = ackNum + 1;
                    }
                } else if (MODE == "SR") {
                    acked[ackNum] = true;
                    while (acked[base]) base++;
                }
            }
        }
    }
}

int main() {
    // 1. Select protocol mode
    int choice = 0;
    cout << "Select protocol mode:\n1. Go-Back-N\n2. Selective Repeat\nEnter choice (1 or 2): ";
    while (!(cin >> choice) || (choice != 1 && choice != 2)) {
        cout << "Invalid input. Enter 1 or 2: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    MODE = (choice == 1) ? "GBN" : "SR";

    cin.ignore(numeric_limits<streamsize>::max(), '\n'); // flush newline

    // 2. Get input string
    string input;
    cout << "Enter the message to send: ";
    getline(cin, input);

    // 3. Prepare packets (1 char per packet)
    for (char c : input) {
        packets.push_back(string(1, c));
    }
    total_packets = (int)packets.size();

    cout << "[SENDER] Mode: " << MODE << ", sending " << total_packets << " packets.\n";

    // 4. Setup UDP socket with IP ending in .40 and port 8080 (sender)
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    sockaddr_in senderAddr{}, receiverAddr{};
    senderAddr.sin_family = AF_INET;
    senderAddr.sin_port = htons(8080);
    inet_pton(AF_INET, "127.0.0.40", &senderAddr.sin_addr);
    bind(sockfd, (struct sockaddr*)&senderAddr, sizeof(senderAddr));

    receiverAddr.sin_family = AF_INET;
    receiverAddr.sin_port = htons(9090);
    inet_pton(AF_INET, "127.0.0.40", &receiverAddr.sin_addr);

    // 5. Run sender and ACK receiver threads
    thread sendThread(sender_thread, sockfd, ref(receiverAddr));
    thread ackThread(receiver_ack_thread, sockfd, total_packets);

    sendThread.join();
    ackThread.join();

    // 6. Send special END packet to notify receiver transmission is complete
    char end_msg[] = "END";
    sendto(sockfd, end_msg, strlen(end_msg), 0, (struct sockaddr*)&receiverAddr, sizeof(receiverAddr));
    cout << "[SENDER] Sent END packet.\n";

    close(sockfd);
    return 0;
}
