// receiver.cpp
#include <iostream>
#include <unistd.h>
#include <arpa/inet.h>
#include <string.h>
#include <cstdlib>
#include <ctime>

using namespace std;

#define WINDOW_SIZE 4
#define MAX_PACKETS 100

// Hardcode protocol mode here
string MODE = "SR"; // Change to "SR" if needed

int expected = 0;
bool received[MAX_PACKETS] = {false};
string packet_data[MAX_PACKETS];

void maybe_send_ack(int sockfd, sockaddr_in &senderAddr, socklen_t addrLen, int seqNum) {
    // 20% packet loss simulation
    if (rand() % 100 < 20) {
        cout << "[RECEIVER] Simulated packet loss for Packet " << seqNum << endl;
        return;
    }

    char ack[1024];
    sprintf(ack, "ACK %d", seqNum);
    sendto(sockfd, ack, strlen(ack), 0, (struct sockaddr*)&senderAddr, addrLen);
    cout << "[RECEIVER] Sent ACK " << seqNum << endl;
}

int main() {
    cout << "[RECEIVER] Mode: " << MODE << endl;
    srand(time(NULL));

    // Setup UDP socket on 127.0.0.40:9090 (receiver)
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    sockaddr_in receiverAddr{}, senderAddr{};
    receiverAddr.sin_family = AF_INET;
    receiverAddr.sin_port = htons(9090);
    inet_pton(AF_INET, "127.0.0.40", &receiverAddr.sin_addr);
    bind(sockfd, (struct sockaddr*)&receiverAddr, sizeof(receiverAddr));

    char buffer[1024];
    socklen_t addrLen = sizeof(senderAddr);

    bool transmission_done = false;

    while (!transmission_done) {
        int len = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr*)&senderAddr, &addrLen);
        if (len > 0) {
            buffer[len] = '\0';

            // Check for special END packet
            if (strcmp(buffer, "END") == 0) {
                cout << "[RECEIVER] Received END packet. Transmission complete.\n";
                transmission_done = true;
                break;
            }

            int seqNum;
            char payload[1024];
            if (sscanf(buffer, "Packet %d:%s", &seqNum, payload) == 2) {
                cout << "[RECEIVER] Received Packet " << seqNum << ": " << payload << endl;

                if (MODE == "GBN") {
                    if (seqNum == expected) {
                        cout << "[RECEIVER] Delivered: " << payload << endl;
                        maybe_send_ack(sockfd, senderAddr, addrLen, seqNum);
                        expected++;
                    } else {
                        // Re-ACK last correctly received packet
                        maybe_send_ack(sockfd, senderAddr, addrLen, expected - 1);
                    }
                } else if (MODE == "SR") {
                    if (!received[seqNum]) {
                        received[seqNum] = true;
                        packet_data[seqNum] = string(payload);
                        maybe_send_ack(sockfd, senderAddr, addrLen, seqNum);
                    }
                    // Deliver in order all received packets starting from expected
                    while (received[expected]) {
                        cout << "[RECEIVER] Delivered: " << packet_data[expected] << endl;
                        expected++;
                    }
                }
            }
        }
    }

    // After receiving all packets, reassemble message and print
    cout << "[RECEIVER] Full message received: ";
    for (int i = 0; i < expected; i++) {
        if (MODE == "GBN") {
            // GBN packets are delivered in order
            cout << packet_data[i];
        } else {
            // SR: safe to print in order since 'expected' advances only when received
            cout << packet_data[i];
        }
    }
    cout << endl;

    close(sockfd);
    return 0;
}
